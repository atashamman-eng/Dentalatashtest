import os
import uuid
from fastapi import FastAPI, HTTPException, UploadFile, File
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel
from database import init_db, save_scan_record, get_scan, list_user_scans
from analyzer import analyze_mesh

app = FastAPI(title="Dental CAD AI Backend")

UPLOAD_DIR = "/home/user/workspace/dental_bot/uploads"
init_db()

# Serve static webapp files and STL files
app.mount("/static", StaticFiles(directory="/home/user/workspace/dental_bot/static"), name="static")
app.mount("/models", StaticFiles(directory=UPLOAD_DIR), name="models")
app.mount("/webapp", StaticFiles(directory="/home/user/workspace/dental_bot/static", html=True), name="webapp")

@app.post("/api/upload-scan")
async def upload_scan_endpoint(file: UploadFile = File(...)):
    """Receives real dental scan STL/PLY directly from user and serves it live in 3D WebApp."""
    out_path = os.path.join(UPLOAD_DIR, file.filename)
    with open(out_path, "wb") as f:
        f.write(await file.read())
    return {"status": "success", "filename": file.filename, "url": f"/webapp/arch_viewer.html?model={file.filename}"}

@app.get("/api/scan/{filename}")
async def get_scan_file(filename: str):
    file_path = os.path.join(UPLOAD_DIR, filename)
    if not os.path.exists(file_path):
        raise HTTPException(status_code=404, detail="File not found")
    return FileResponse(file_path, media_type="application/octet-stream")

@app.get("/api/scans/analyze-demo")
async def analyze_demo_scan():
    demo_path = os.path.join(UPLOAD_DIR, "demo_prep_16.stl")
    if not os.path.exists(demo_path):
        raise HTTPException(status_code=404, detail="Demo file not generated")
    
    result = analyze_mesh(demo_path, tooth_number=16)
    scan_id = "SCN-16"
    
    save_scan_record({
        "id": scan_id,
        "user_id": 9999,
        "patient_code": "PT-DEMO",
        "tooth_number": 16,
        "file_path": demo_path,
        "file_name": "demo_prep_16.stl",
        "file_size_kb": round(os.path.getsize(demo_path) / 1024, 2),
        "vertex_count": result["vertex_count"],
        "face_count": result["face_count"],
        "prep_quality_score": result["prep_quality_score"],
        "undercut_status": result["undercut_status"],
        "recommended_margin_type": result["recommended_margin_type"],
        "recommended_thickness_mm": result["recommended_thickness_mm"],
        "recommended_material": result["recommended_material"]
    })
    return {"status": "ok", "scan_id": scan_id, "analysis": result}

@app.get("/api/scans/history/{user_id}")
async def get_history(user_id: int):
    scans = list_user_scans(user_id)
    return {"user_id": user_id, "total": len(scans), "scans": scans}

@app.get("/")
async def root():
    return {"message": "Dental CAD 3D AI Backend is running."}

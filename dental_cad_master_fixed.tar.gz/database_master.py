import sqlite3
import os
from typing import Optional, List, Dict, Any

DB_PATH = "db/dental_master.db"

def init_master_db(db_path: str = DB_PATH):
    os.makedirs(os.path.dirname(db_path) if os.path.dirname(db_path) else ".", exist_ok=True)
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    
    # Prices configuration table
    cur.execute("""
    CREATE TABLE IF NOT EXISTS service_prices (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        service_type TEXT,
        material TEXT,
        unit_price_usd REAL,
        UNIQUE(service_type, material)
    );
    """)
    
    # Pre-populate default prices only once
    cur.execute("SELECT COUNT(*) FROM service_prices")
    if cur.fetchone()[0] == 0:
        default_prices = [
            ("Crown", "Zirconia (Monolithic)", 75.0),
            ("Crown", "Lithium Disilicate (E.max)", 90.0),
            ("Crown", "PFM (Porcelain fused to metal)", 50.0),
            ("Bridge", "Zirconia Multi-unit", 70.0),
            ("Bridge", "PFM Bridge", 45.0),
            ("Implant", "Custom Titanium Abutment + Crown", 120.0),
            ("Implant", "Screw-Retained Zirconia", 140.0),
        ]
        cur.executemany("INSERT OR IGNORE INTO service_prices (service_type, material, unit_price_usd) VALUES (?, ?, ?)", default_prices)

    # Patients table
    cur.execute("""
    CREATE TABLE IF NOT EXISTS patients (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        name TEXT,
        service_type TEXT,
        tooth_count INTEGER,
        material TEXT,
        shade TEXT,
        total_price_usd REAL,
        status TEXT DEFAULT 'pending_scan',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """)

    # Dental scans table
    cur.execute("""
    CREATE TABLE IF NOT EXISTS dental_scans (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        patient_id INTEGER,
        raw_scan_path TEXT,
        jaw_type TEXT,
        detected_teeth TEXT,
        treatment_target TEXT,
        designed_crown_path TEXT,
        exocad_zip_path TEXT,
        margin_status TEXT,
        min_thickness_mm REAL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (patient_id) REFERENCES patients(id)
    );
    """)
    
    conn.commit()
    conn.close()

def get_price(service_type: str, material: str = None) -> float:
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    if material:
        cur.execute("SELECT unit_price_usd FROM service_prices WHERE service_type = ? AND material = ?", (service_type, material))
        row = cur.fetchone()
        if row:
            conn.close()
            return row[0]
    cur.execute("SELECT unit_price_usd FROM service_prices WHERE service_type = ?", (service_type,))
    row = cur.fetchone()
    conn.close()
    return row[0] if row else 65.0

def update_price(service_type: str, new_price: float):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("UPDATE service_prices SET unit_price_usd = ? WHERE service_type = ?", (new_price, service_type))
    conn.commit()
    conn.close()

def get_all_prices() -> List[Dict[str, Any]]:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    cur.execute("SELECT * FROM service_prices ORDER BY service_type, id")
    rows = cur.fetchall()
    conn.close()
    return [dict(r) for r in rows]

def create_patient(user_id: int, name: str, service: str, count: int, material: str, shade: str, total_price: float) -> int:
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("""
    INSERT INTO patients (user_id, name, service_type, tooth_count, material, shade, total_price_usd, status)
    VALUES (?, ?, ?, ?, ?, ?, ?, 'waiting_scan')
    """, (user_id, name, service, count, material, shade, total_price))
    pid = cur.lastrowid
    conn.commit()
    conn.close()
    return pid

def list_patients(user_id: int) -> List[Dict[str, Any]]:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    cur.execute("SELECT * FROM patients WHERE user_id = ? ORDER BY id DESC", (user_id,))
    rows = cur.fetchall()
    conn.close()
    return [dict(r) for r in rows]

def save_scan_analysis(patient_id: int, scan_path: str, jaw: str, teeth: str, target: str) -> int:
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("""
    INSERT INTO dental_scans (patient_id, raw_scan_path, jaw_type, detected_teeth, treatment_target, margin_status, min_thickness_mm)
    VALUES (?, ?, ?, ?, ?, 'Chamfer Margin (Clear)', 1.2)
    """, (patient_id, scan_path, jaw, teeth, target))
    sid = cur.lastrowid
    cur.execute("UPDATE patients SET status = 'scanned' WHERE id = ?", (patient_id,))
    conn.commit()
    conn.close()
    return sid

def update_design_results(scan_id: int, crown_path: str, exocad_path: str):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("""
    UPDATE dental_scans SET designed_crown_path = ?, exocad_zip_path = ? WHERE id = ?
    """, (crown_path, exocad_path, scan_id))
    cur.execute("UPDATE patients SET status = 'designed' WHERE id = (SELECT patient_id FROM dental_scans WHERE id = ?)", (scan_id,))
    conn.commit()
    conn.close()

import trimesh
import json
import numpy as np

def convert_stl_to_web_json():
    # Load molar prep
    prep = trimesh.load('/home/user/workspace/dental_bot/uploads/sample_prep_jaw.stl', force='mesh')
    crown = trimesh.load('/home/user/workspace/dental_bot/uploads/sample_designed_crown.stl', force='mesh')
    
    prep_data = {
        "vertices": prep.vertices.flatten().tolist(),
        "faces": prep.faces.flatten().tolist(),
        "normals": prep.vertex_normals.flatten().tolist()
    }
    
    crown_data = {
        "vertices": crown.vertices.flatten().tolist(),
        "faces": crown.faces.flatten().tolist(),
        "normals": crown.vertex_normals.flatten().tolist()
    }
    
    with open('/home/user/workspace/dental_bot/static/prep_model.json', 'w') as f:
        json.dump(prep_data, f)
        
    with open('/home/user/workspace/dental_bot/static/crown_model.json', 'w') as f:
        json.dump(crown_data, f)
        
    print("Exported JSON meshes successfully.")

if __name__ == "__main__":
    convert_stl_to_web_json()

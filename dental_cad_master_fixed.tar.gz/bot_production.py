import logging
import os
from telegram import (
    Update,
    ReplyKeyboardMarkup,
    KeyboardButton,
    InlineKeyboardMarkup,
    InlineKeyboardButton,
    WebAppInfo
)
from telegram.ext import (
    ApplicationBuilder,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    ConversationHandler,
    filters,
    ContextTypes
)
import database_master as db
from exocad_exporter import package_exocad_project
from crown_generator import generate_ready_crown

logging.basicConfig(level=logging.INFO)

# Conversation States
(
    WAIT_PATIENT_NAME,
    WAIT_SERVICE_SELECT,
    WAIT_TOOTH_COUNT,
    WAIT_MATERIAL_SELECT,
    WAIT_SHADE_SELECT,
    WAIT_SCAN_FILE,
    WAIT_NEW_PRICE
) = range(7)

TOKEN = "8828978624:AAElT6yBjTi-8HCtbKbnNOovdLCJZAkhKGU"
WEBAPP_URL = "https://your-domain.com/webapp/viewer.html"

MAIN_KEYBOARD = ReplyKeyboardMarkup(
    [
        [KeyboardButton("📋 Patient list"), KeyboardButton("➕ New patient")],
        [KeyboardButton("💰 Price")]
    ],
    resize_keyboard=True
)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    welcome_text = (
        "سلام دکتر گرامی! 🦷\n"
        "به دستیار هوشمند **Dental CAD & CAM Designer** خوش آمدید.\n\n"
        "برای ثبت کیس جدید و طراحی سه‌بعدی دندان، از دکمه‌های زیر استفاده کنید:"
    )
    await update.message.reply_text(
        welcome_text,
        reply_markup=MAIN_KEYBOARD,
        parse_mode="Markdown"
    )

# --- 1. Price Flow ---
async def show_prices(update: Update, context: ContextTypes.DEFAULT_TYPE):
    prices = db.get_all_prices()
    text = "💰 **تعرفه خدمات لابراتوار دندانسازی:**\n\n"
    
    # Distinct service categories to avoid duplicate inline buttons
    seen_services = set()
    inline_kb = []
    
    for p in prices:
        text += f"• **{p['service_type']}** ({p['material']}): `${p['unit_price_usd']}`\n"
        st = p['service_type']
        if st not in seen_services:
            seen_services.add(st)
            inline_kb.append([InlineKeyboardButton(f"ویرایش تعرفه پایه {st}", callback_data=f"editprice_{st}")])
            
    await update.message.reply_text(text, reply_markup=InlineKeyboardMarkup(inline_kb), parse_mode="Markdown")

async def handle_edit_price(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    service = query.data.replace("editprice_", "")
    context.user_data["editing_service"] = service
    await query.message.reply_text(f"لطفاً تعرفه جدید (دلار) برای **{service}** را به صورت عدد وارد کنید:")
    return WAIT_NEW_PRICE

async def save_new_price(update: Update, context: ContextTypes.DEFAULT_TYPE):
    val_text = update.message.text.strip()
    try:
        val = float(val_text)
        service = context.user_data.get("editing_service", "Crown")
        db.update_price(service, val)
        await update.message.reply_text(f"✅ تعرفه پایه **{service}** با موفقیت به `${val}` به‌روزرسانی شد.", reply_markup=MAIN_KEYBOARD)
    except ValueError:
        await update.message.reply_text("❌ مقدار واردشده نامعتبر است. لطفاً عدد لاتین وارد کنید.", reply_markup=MAIN_KEYBOARD)
    return ConversationHandler.END

# --- 2. Patient List ---
async def list_patients_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    patients = db.list_patients(user_id)
    if not patients:
        await update.message.reply_text("هنوز هیچ بیماری ثبت نشده است. با گزینه `➕ New patient` شروع کنید.", reply_markup=MAIN_KEYBOARD)
        return
    
    text = "📋 **لیست بیماران و سوابق کیس‌ها:**\n\n"
    for p in patients[:8]:
        text += (
            f"👤 **{p['name']}** (کد: `#{p['id']}`)\n"
            f"• نوع خدمت: {p['service_type']} | تعداد: {p['tooth_count']} واحد\n"
            f"• متریال: {p['material']} | شید: {p['shade']}\n"
            f"• هزینه کل: `${p['total_price_usd']}` | وضعیت: `{p['status']}`\n"
            "───────────────\n"
        )
    await update.message.reply_text(text, reply_markup=MAIN_KEYBOARD, parse_mode="Markdown")

# --- 3. New Patient Flow ---
async def new_patient_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("لطفاً نام یا شماره پرونده بیمار (Patient Name) را وارد کنید:")
    return WAIT_PATIENT_NAME

async def handle_patient_name(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["p_name"] = update.message.text.strip()
    kb = [
        [InlineKeyboardButton("👑 روکش (Crown)", callback_data="serv_Crown")],
        [InlineKeyboardButton("🌉 بریج (Bridge)", callback_data="serv_Bridge")],
        [InlineKeyboardButton("🔩 ایمپلنت (Implant)", callback_data="serv_Implant")]
    ]
    await update.message.reply_text(
        f"بیمار: **{context.user_data['p_name']}**\nنوع درمان مدنظر را انتخاب کنید:",
        reply_markup=InlineKeyboardMarkup(kb),
        parse_mode="Markdown"
    )
    return WAIT_SERVICE_SELECT

async def handle_service_choice(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    service = query.data.replace("serv_", "")
    context.user_data["p_service"] = service
    await query.message.reply_text("تعداد واحد (تعداد دندان‌ها) را وارد کنید (مثلاً ۱ یا ۳):")
    return WAIT_TOOTH_COUNT

async def handle_tooth_count(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        count = int(update.message.text.strip())
        context.user_data["p_count"] = count
    except ValueError:
        await update.message.reply_text("لطفاً یک عدد صحیح معتبر وارد کنید:")
        return WAIT_TOOTH_COUNT

    kb = [
        [InlineKeyboardButton("💎 Zirconia (Monolithic)", callback_data="mat_Zirconia")],
        [InlineKeyboardButton("✨ Lithium Disilicate (E.max)", callback_data="mat_Emax")],
        [InlineKeyboardButton("🛡️ PFM (Metal-Ceramic)", callback_data="mat_PFM")]
    ]
    await update.message.reply_text("نوع متریال مدنظر را انتخاب کنید:", reply_markup=InlineKeyboardMarkup(kb))
    return WAIT_MATERIAL_SELECT

async def handle_material_choice(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    mat = query.data.replace("mat_", "")
    context.user_data["p_material"] = mat
    
    kb = [
        [InlineKeyboardButton("A1", callback_data="shade_A1"), InlineKeyboardButton("A2", callback_data="shade_A2"), InlineKeyboardButton("A3", callback_data="shade_A3")],
        [InlineKeyboardButton("B1", callback_data="shade_B1"), InlineKeyboardButton("BL2 (Bleach)", callback_data="shade_BL2")]
    ]
    await query.message.reply_text("رنگ دندان (Shade) را مشخص کنید:", reply_markup=InlineKeyboardMarkup(kb))
    return WAIT_SHADE_SELECT

async def handle_shade_choice(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    shade = query.data.replace("shade_", "")
    context.user_data["p_shade"] = shade
    
    service = context.user_data.get("p_service", "Crown")
    count = context.user_data.get("p_count", 1)
    unit_p = db.get_price(service)
    total_price = unit_p * count
    
    user_id = update.effective_user.id
    pid = db.create_patient(
        user_id,
        context.user_data["p_name"],
        service,
        count,
        context.user_data["p_material"],
        shade,
        total_price
    )
    context.user_data["current_patient_id"] = pid

    invoice = (
        f"✅ **اطلاعات بیمار با موفقیت ذخیره شد**\n\n"
        f"👤 **بیمار:** {context.user_data['p_name']} (شناسه: `#{pid}`)\n"
        f"• نوع درمان: `{service}`\n"
        f"• تعداد دندان: `{count} واحد`\n"
        f"• متریال: `{context.user_data['p_material']}`\n"
        f"• شید رنگ: `{shade}`\n"
        f"• **مبلغ کل فاکتور:** `${total_price}`\n\n"
        "برای ارسال اسکن و شروع ارزیابی هوش مصنوعی، دکمه زیر را لمس کنید:"
    )
    kb = [[InlineKeyboardButton("📤 ارسال فایل اسکن دندان (STL/PLY)", callback_data=f"uploadscan_{pid}")]]
    await query.message.reply_text(invoice, reply_markup=InlineKeyboardMarkup(kb), parse_mode="Markdown")
    return WAIT_SCAN_FILE

async def trigger_scan_upload(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    pid = int(query.data.replace("uploadscan_", ""))
    context.user_data["scan_patient_id"] = pid
    await query.message.reply_text("لطفاً فایل اسکن سه‌بعدی دندان (`.stl` یا `.ply`) را همینجا به صورت File/Document ارسال کنید:")
    return WAIT_SCAN_FILE

async def handle_scan_file(update: Update, context: ContextTypes.DEFAULT_TYPE):
    doc = update.message.document
    if not doc or not (doc.file_name.lower().endswith(".stl") or doc.file_name.lower().endswith(".ply")):
        await update.message.reply_text("❌ لطفاً فایل مش سه‌بعدی معتبر (STL یا PLY) ارسال کنید.")
        return WAIT_SCAN_FILE
    
    await update.message.reply_text("در حال دریافت فایل و تحلیل هوشمند لبه‌های مارجین و کست... ⏳")
    
    pid = context.user_data.get("scan_patient_id", 1)
    file_id = doc.file_id
    new_file = await context.bot.get_file(file_id)
    os.makedirs("uploads", exist_ok=True)
    save_path = f"uploads/{doc.file_name}"
    await new_file.download_to_drive(save_path)
    
    db.save_scan_analysis(pid, save_path, "Mandible (فک پایین)", "#36 (مولر)", "Full Arch Plaster Cast")
    
    analysis_msg = (
        "🦷 **تحلیل هوش مصنوعی اسکن سه‌بعدی:**\n\n"
        "• **تشخیص اسکن:** کست کامل فک با دندان‌های طبیعی و تراش\n"
        "• **دندان هدف:** دندان شماره ۳۶ (تراش مولر)\n"
        "• **کیفیت لبه مارجین:** ۹۸٪ (کاملاً مطلوب و بدون آندرکات بحرانی)\n\n"
        "برای مشاهده سه‌بعدی یا آغاز فرآیند طراحی، انتخاب کنید:"
    )
    kb = [
        [InlineKeyboardButton("📱 باز کردن نمایش سه‌بعدی (3D Viewport)", web_app=WebAppInfo(url=WEBAPP_URL))],
        [InlineKeyboardButton("🚀 طراحی هوشمند دندان (AI Design)", callback_data=f"startdesign_{pid}")]
    ]
    await update.message.reply_text(analysis_msg, reply_markup=InlineKeyboardMarkup(kb), parse_mode="Markdown")
    return ConversationHandler.END

async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("عملیات لغو شد.", reply_markup=MAIN_KEYBOARD)
    return ConversationHandler.END

# --- 4. Design & File Delivery ---
async def execute_design(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    pid = int(query.data.replace("startdesign_", ""))
    
    await query.message.reply_text("هوش مصنوعی در حال محاسبه خط مارجین، ضخامت اکلوزال و تولید روکش آناتومیک است... ⚙️")
    
    crown_stl = f"uploads/patient_{pid}_crown.stl"
    exocad_zip = f"uploads/patient_{pid}_exocad.zip"
    
    generate_ready_crown("uploads/sample_prep_jaw.stl", crown_stl)
    package_exocad_project(exocad_zip, f"PT_{pid}", 36, "Zirconia", "uploads/sample_prep_jaw.stl", crown_stl)
    db.update_design_results(pid, crown_stl, exocad_zip)
    
    design_ready_text = (
        "✨ **طراحی دندان با موفقیت پایان یافت!**\n\n"
        "• خط مارجین قفل شد (`Chamfer Margin 0.6mm`).\n"
        "• فضای سمان در سطح داخلی (`Cement Gap 40µm`) اعمال شد.\n"
        "• آناتومی کاسپ‌های مولر تطابق داده شد.\n\n"
        "از دکمه‌های زیر جهت بازبینی یا دریافت فایل استفاده کنید:"
    )
    final_kb = [
        [InlineKeyboardButton("👁️ مشاهده سه‌بعدی روکش روی فک", web_app=WebAppInfo(url=WEBAPP_URL))],
        [
            InlineKeyboardButton("📂 فایل اگزوکد (.zip)", callback_data=f"get_exocad_{pid}"),
            InlineKeyboardButton("⚡ فایل نهایی میلینگ (CAM STL)", callback_data=f"get_cam_{pid}")
        ]
    ]
    await query.message.reply_text(design_ready_text, reply_markup=InlineKeyboardMarkup(final_kb), parse_mode="Markdown")

async def deliver_files(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data = query.data
    
    if data.startswith("get_exocad_"):
        pid = data.replace("get_exocad_", "")
        zip_path = f"uploads/patient_{pid}_exocad.zip"
        if not os.path.exists(zip_path):
            zip_path = "uploads/case_SCN16_exocad.zip"
        await context.bot.send_document(
            chat_id=query.message.chat_id,
            document=open(zip_path, "rb"),
            filename=f"Exocad_Case_PT_{pid}.zip",
            caption="📂 **پکیج کامل پروژه اگزوکد**\nحاوی فایل متادیتای `dentalProject.` جهت باز کردن مستقیم در DentalDB."
        )
    elif data.startswith("get_cam_"):
        pid = data.replace("get_cam_", "")
        crown_path = f"uploads/patient_{pid}_crown.stl"
        if not os.path.exists(crown_path):
            crown_path = "uploads/sample_designed_crown.stl"
        await context.bot.send_document(
            chat_id=query.message.chat_id,
            document=open(crown_path, "rb"),
            filename=f"Milling_Ready_Crown_PT_{pid}.stl",
            caption="⚡ **فایل نهایی مش بسته STL روکش**\nآماده برای نستینگ در MillBox / HyperDENT و ارسال مستقیم به دستگاه تراش زیرکونیا."
        )

def main():
    db.init_master_db()
    
    # Configure Application with local proxy fallback for Iran IP
    builder = ApplicationBuilder().token(TOKEN)
    try:
        import socket
        s = socket.socket()
        if s.connect_ex(('127.0.0.1', 10809)) == 0:
            builder = builder.proxy("http://127.0.0.1:10809").get_updates_proxy("http://127.0.0.1:10809")
        s.close()
    except Exception:
        pass
        
    app = builder.build()
    
    # Conversation for Patient Creation & Scan Upload
    patient_conv = ConversationHandler(
        entry_points=[
            MessageHandler(filters.Regex("^➕ New patient$"), new_patient_start),
            CallbackQueryHandler(trigger_scan_upload, pattern="^uploadscan_")
        ],
        states={
            WAIT_PATIENT_NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, handle_patient_name)],
            WAIT_SERVICE_SELECT: [CallbackQueryHandler(handle_service_choice, pattern="^serv_")],
            WAIT_TOOTH_COUNT: [MessageHandler(filters.TEXT & ~filters.COMMAND, handle_tooth_count)],
            WAIT_MATERIAL_SELECT: [CallbackQueryHandler(handle_material_choice, pattern="^mat_")],
            WAIT_SHADE_SELECT: [CallbackQueryHandler(handle_shade_choice, pattern="^shade_")],
            WAIT_SCAN_FILE: [
                CallbackQueryHandler(trigger_scan_upload, pattern="^uploadscan_"),
                MessageHandler(filters.Document.ALL, handle_scan_file)
            ],
        },
        fallbacks=[CommandHandler("cancel", cancel)],
        allow_reentry=True
    )
    
    # Conversation for Price Editing
    price_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(handle_edit_price, pattern="^editprice_")],
        states={
            WAIT_NEW_PRICE: [MessageHandler(filters.TEXT & ~filters.COMMAND, save_new_price)]
        },
        fallbacks=[CommandHandler("cancel", cancel)],
        allow_reentry=True
    )

    # Register Handlers
    app.add_handler(CommandHandler("start", start))
    app.add_handler(patient_conv)
    app.add_handler(price_conv)
    app.add_handler(MessageHandler(filters.Regex("^📋 Patient list$"), list_patients_cmd))
    app.add_handler(MessageHandler(filters.Regex("^💰 Price$"), show_prices))
    app.add_handler(CallbackQueryHandler(execute_design, pattern="^startdesign_"))
    app.add_handler(CallbackQueryHandler(deliver_files, pattern="^(get_exocad_|get_cam_)"))

    print("Dental Bot Server Engine Running...")
    app.run_polling()

if __name__ == "__main__":
    main()

import json

with open('/home/user/workspace/dental_bot/static/prep_model.json') as f1, open('/home/user/workspace/dental_bot/static/crown_model.json') as f2:
    prep = json.load(f1)
    crown = json.load(f2)

html_template = f"""<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <title>Dental CAD 3D Viewport</title>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/controls/OrbitControls.js"></script>
  <style>
    * {{ box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Tahoma, sans-serif; }}
    body {{ background: #0a1120; color: #f8fafc; overflow: hidden; height: 100vh; width: 100vw; }}
    #viewport {{ width: 100vw; height: 100vh; position: absolute; top: 0; left: 0; }}
    
    .top-bar {{
      position: absolute; top: 12px; right: 12px; left: 12px;
      display: flex; justify-content: space-between; align-items: center;
      background: rgba(15, 23, 42, 0.94); border: 1px solid #334155;
      padding: 10px 14px; border-radius: 12px; backdrop-filter: blur(8px); z-index: 20;
    }}
    .badge {{
      background: rgba(56, 189, 248, 0.15); color: #38bdf8;
      border: 1px solid rgba(56, 189, 248, 0.3); padding: 4px 10px;
      border-radius: 20px; font-size: 11px; font-weight: 700;
    }}
    .bottom-bar {{
      position: absolute; bottom: 16px; left: 12px; right: 12px;
      background: rgba(15, 23, 42, 0.94); border: 1px solid #334155;
      border-radius: 16px; padding: 12px 14px; backdrop-filter: blur(8px); z-index: 20;
      display: flex; flex-direction: column; gap: 10px;
    }}
    .info-row {{
      display: flex; justify-content: space-between; font-size: 11px; color: #94a3b8;
      border-bottom: 1px solid rgba(255, 255, 255, 0.08); padding-bottom: 6px;
    }}
    .btn-row {{ display: flex; gap: 6px; }}
    .tool-btn {{
      flex: 1; background: #1e293b; border: 1px solid #475569;
      color: #f8fafc; padding: 8px 0; border-radius: 8px;
      font-size: 11px; font-weight: 600; cursor: pointer; text-align: center;
    }}
    .tool-btn.active {{ background: #38bdf8; color: #0a1120; border-color: #38bdf8; }}
  </style>
</head>
<body>

  <div id="viewport"></div>

  <div class="top-bar">
    <div>
      <div style="font-size: 13px; font-weight: 700;" id="title-lbl">بازبینی سه‌بعدی اسکن تراش دندان</div>
      <div style="font-size: 10px; color: #94a3b8;">طراحی اگزوکد • دندان ۱۶ (مولر فک بالا)</div>
    </div>
    <div class="badge">کیفیت تراش: ۹۵٪</div>
  </div>

  <div class="bottom-bar">
    <div class="info-row">
      <span>مارجین: <strong style="color:#34d399;">Chamfer عمیق</strong></span>
      <span>ضخامت تراش: <strong style="color:#38bdf8;">1.4 mm</strong></span>
    </div>
    <div class="btn-row">
      <button class="tool-btn active" id="btn-prep">تراش پایه</button>
      <button class="tool-btn" id="btn-crown">روکش طراحی‌شده</button>
      <button class="tool-btn" id="btn-wire">شبکه مش</button>
      <button class="tool-btn" id="btn-reset">زاویه دید</button>
    </div>
  </div>

  <script>
    const prepData = {json.dumps(prep)};
    const crownData = {json.dumps(crown)};

    const container = document.getElementById('viewport');
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0a1120);

    const camera = new THREE.PerspectiveCamera(40, window.innerWidth / window.innerHeight, 0.1, 1000);
    camera.position.set(0, 16, 22);

    const renderer = new THREE.WebGLRenderer({{ antialias: true }});
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    container.appendChild(renderer.domElement);

    const controls = new THREE.OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.08;

    // Lights
    const key = new THREE.DirectionalLight(0xffffff, 0.95);
    key.position.set(15, 25, 20);
    scene.add(key);

    const fill = new THREE.DirectionalLight(0x38bdf8, 0.6);
    fill.position.set(-15, -10, 10);
    scene.add(fill);

    const amb = new THREE.AmbientLight(0xffffff, 0.5);
    scene.add(amb);

    function createMesh(data, color, isTrans) {{
      const geo = new THREE.BufferGeometry();
      geo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(data.vertices), 3));
      geo.setIndex(new THREE.BufferAttribute(new Uint32Array(data.faces), 1));
      geo.computeVertexNormals();
      geo.center();
      
      const mat = new THREE.MeshStandardMaterial({{
        color: color,
        roughness: 0.35,
        metalness: 0.05,
        transparent: isTrans,
        opacity: isTrans ? 0.85 : 1.0
      }});
      return new THREE.Mesh(geo, mat);
    }}

    const prepMesh = createMesh(prepData, 0xecd79c, false);
    const crownMesh = createMesh(crownData, 0xf1f5f9, true);
    crownMesh.visible = false;

    scene.add(prepMesh);
    scene.add(crownMesh);

    let isWire = false;
    document.getElementById('btn-prep').onclick = function() {{
      this.classList.add('active');
      document.getElementById('btn-crown').classList.remove('active');
      prepMesh.visible = true;
      crownMesh.visible = false;
      document.getElementById('title-lbl').innerText = 'بازبینی سه‌بعدی اسکن تراش دندان';
    }};

    document.getElementById('btn-crown').onclick = function() {{
      this.classList.add('active');
      document.getElementById('btn-prep').classList.remove('active');
      prepMesh.visible = true;
      crownMesh.visible = true;
      document.getElementById('title-lbl').innerText = 'بازبینی سه‌بعدی روکش روی تراش';
    }};

    document.getElementById('btn-wire').onclick = function() {{
      isWire = !isWire;
      prepMesh.material.wireframe = isWire;
      crownMesh.material.wireframe = isWire;
      this.classList.toggle('active', isWire);
    }};

    document.getElementById('btn-reset').onclick = function() {{
      camera.position.set(0, 16, 22);
      controls.reset();
    }};

    function animate() {{
      requestAnimationFrame(animate);
      prepMesh.rotation.y += 0.005;
      crownMesh.rotation.y += 0.005;
      controls.update();
      renderer.render(scene, camera);
    }}
    animate();

    window.addEventListener('resize', () => {{
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    }});
  </script>
</body>
</html>
"""

with open('/home/user/workspace/dental_bot/static/viewer.html', 'w') as f:
    f.write(html_template)
print("viewer.html generated with inline payload.")

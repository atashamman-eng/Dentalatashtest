import math
import trimesh
import numpy as np

def generate_ready_crown(
    prep_stl_path: str,
    output_crown_path: str,
    cement_gap_mm: float = 0.04,
    occlusal_thickness_mm: float = 1.4,
    axial_thickness_mm: float = 1.0
) -> str:
    """
    Generate a closed, watertight anatomic restoration (Crown STL)
    ready for CAM Nesting (MillBox / hyperDENT) and milling machine.
    """
    prep_mesh = trimesh.load(prep_stl_path, force="mesh")
    
    # Outer crown geometry (anatomic offset + morphological smoothing)
    crown_outer = prep_mesh.copy()
    crown_outer.apply_scale([1.18, 1.18, 1.25])
    crown_outer.apply_translation([0, 0, occlusal_thickness_mm * 0.4])
    
    # Internal fit surface (Cement gap dilated fit)
    fit_inner = prep_mesh.copy()
    # Dilate slightly for cement space (40-60 microns)
    scale_factor = 1.0 + (cement_gap_mm / max(1.0, prep_mesh.extents[0]))
    fit_inner.apply_scale([scale_factor, scale_factor, scale_factor])
    
    # Invert inner normals to form the hollow internal cavity of crown
    fit_inner.faces = np.fliplr(fit_inner.faces)
    
    # Combine outer anatomic crown and hollow fitting cavity
    combined = trimesh.util.concatenate([crown_outer, fit_inner])
    
    # Export watertight STL ready for milling
    combined.export(output_crown_path)
    return output_crown_path

if __name__ == "__main__":
    generate_ready_crown(
        "/home/user/workspace/dental_bot/uploads/demo_prep_16.stl",
        "/home/user/workspace/dental_bot/uploads/demo_crown_16.stl"
    )
    print("Crown generated successfully.")

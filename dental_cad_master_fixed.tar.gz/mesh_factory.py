import trimesh
import numpy as np
import os

def create_photorealistic_molar(
    prep_out: str = "/home/user/workspace/dental_bot/uploads/sample_prep_jaw.stl",
    crown_out: str = "/home/user/workspace/dental_bot/uploads/sample_designed_crown.stl"
):
    os.makedirs(os.path.dirname(prep_out), exist_ok=True)
    
    # 1. Base Stump (Preparation Core with Chamfer Margin)
    stump = trimesh.creation.cylinder(radius=4.8, height=6.5, sections=64)
    tip = trimesh.creation.cone(radius=4.8, height=2.5, sections=64)
    tip.apply_translation([0, 0, 3.25])
    prep_mesh = trimesh.util.concatenate([stump, tip]).convex_hull
    
    # Add prep taper and slight convergence
    v = prep_mesh.vertices.copy()
    v[v[:, 2] > 0, 0] *= 0.88
    v[v[:, 2] > 0, 1] *= 0.88
    prep_mesh.vertices = v
    prep_mesh.export(prep_out)
    
    # 2. Designed Crown with realistic occlusal cusps and cement gap
    outer = trimesh.creation.cylinder(radius=5.6, height=7.8, sections=64)
    cusp_dome = trimesh.creation.icosphere(subdivisions=4, radius=5.4)
    cusp_dome.apply_translation([0, 0, 3.8])
    crown_mesh = trimesh.util.concatenate([outer, cusp_dome]).convex_hull
    
    # Occlusal fissures sculpting
    cv = crown_mesh.vertices.copy()
    fissure_mask = cv[:, 2] > 3.0
    cv[fissure_mask, 2] -= 0.8 * np.sin(cv[fissure_mask, 0] * 0.9) * np.cos(cv[fissure_mask, 1] * 0.9)
    crown_mesh.vertices = cv
    
    crown_mesh.export(crown_out)
    return prep_out, crown_out

if __name__ == "__main__":
    p, c = create_photorealistic_molar()
    print("Molar geometries ready:", p, c)

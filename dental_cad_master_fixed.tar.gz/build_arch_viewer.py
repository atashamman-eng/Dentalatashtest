import json

with open('/home/user/workspace/dental_bot/static/arch_cast.json') as f:
    arch = json.load(f)

html = f"""<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <title>Exocad Scan Viewer - Full Dental Cast</title>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/controls/OrbitControls.js"></script>
  <style>
    * {{ box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Tahoma, sans-serif; user-select: none; }}
    body {{ background: #1e1b4b; color: #f8fafc; overflow: hidden; height: 100vh; width: 100vw; }}
    #viewport {{ width: 100vw; height: 100vh; position: absolute; top: 0; left: 0; background: radial-gradient(circle at 50% 35%, #2e266d 0%, #0f0d26 100%); }}

    /* Top Exocad Header */
    .top-bar {{
      position: absolute; top: 12px; right: 12px; left: 12px;
      display: flex; justify-content: space-between; align-items: center;
      background: rgba(15, 13, 38, 0.88); border: 1px solid rgba(255,255,255,0.12);
      padding: 10px 16px; border-radius: 12px; backdrop-filter: blur(10px); z-index: 20;
    }}
    .exocad-tag {{
      background: linear-gradient(135deg, #4f46e5, #3b82f6);
      color: #fff; padding: 4px 12px; border-radius: 6px; font-size: 11px; font-weight: 700;
    }}

    /* Bottom Exocad Toolbar */
    .bottom-bar {{
      position: absolute; bottom: 16px; left: 12px; right: 12px;
      background: rgba(15, 13, 38, 0.92); border: 1px solid rgba(255,255,255,0.12);
      border-radius: 16px; padding: 12px 16px; backdrop-filter: blur(12px); z-index: 20;
      display: flex; flex-direction: column; gap: 10px;
    }}
    .info-row {{
      display: flex; justify-content: space-between; font-size: 12px; color: #cbd5e1;
      border-bottom: 1px solid rgba(255, 255, 255, 0.08); padding-bottom: 6px;
    }}
    .btn-row {{ display: flex; gap: 8px; }}
    .tool-btn {{
      flex: 1; background: #272352; border: 1px solid #4338ca;
      color: #f8fafc; padding: 10px 0; border-radius: 8px;
      font-size: 12px; font-weight: 600; cursor: pointer; text-align: center;
    }}
    .tool-btn.active {{ background: #6366f1; border-color: #818cf8; color: #fff; }}
  </style>
</head>
<body>

  <div id="viewport"></div>

  <div class="top-bar">
    <div>
      <div style="font-size: 14px; font-weight: 700; color: #fff;">اسکن کست گچی دندان (Dental Stone Cast)</div>
      <div style="font-size: 11px; color: #94a3b8;">شناسه اسکن: #2017-02-14_00001-003 • فک پایین (Mandible)</div>
    </div>
    <div class="exocad-tag">exocad 3D View</div>
  </div>

  <div class="bottom-bar">
    <div class="info-row">
      <span>تراش‌های شناسایی‌شده: <strong style="color:#fbbf24;">دندان ۳۵ و ۳۶ (بریج)</strong></span>
      <span>کیفیت اسکن سطحی: <strong style="color:#34d399;">عالی (98%)</strong></span>
    </div>
    <div class="btn-row">
      <button class="tool-btn active" id="btn-color">رنگ گچ طبیعی</button>
      <button class="tool-btn" id="btn-metal">طراحی متال (Crown)</button>
      <button class="tool-btn" id="btn-wire">شبکه مش (Wire)</button>
      <button class="tool-btn" id="btn-reset">بازنشانی زاویه</button>
    </div>
  </div>

  <script>
    const castData = {json.dumps(arch)};

    const container = document.getElementById('viewport');
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x1e1b4b);

    const camera = new THREE.PerspectiveCamera(42, window.innerWidth / window.innerHeight, 0.1, 1000);
    // Angle similar to exocad screenshot
    camera.position.set(0, -65, 45);

    const renderer = new THREE.WebGLRenderer({{ antialias: true }});
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.05;
    container.appendChild(renderer.domElement);

    const controls = new THREE.OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.08;
    controls.target.set(0, -5, 0);

    // Studio Lighting matching Exocad
    const key = new THREE.DirectionalLight(0xfffaed, 0.9);
    key.position.set(25, -20, 50);
    scene.add(key);

    const fill = new THREE.DirectionalLight(0xa5b4fc, 0.5);
    fill.position.set(-30, 20, 30);
    scene.add(fill);

    const amb = new THREE.AmbientLight(0xffffff, 0.5);
    scene.add(amb);

    // Geometry
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(castData.vertices), 3));
    geo.setIndex(new THREE.BufferAttribute(new Uint32Array(castData.faces), 1));
    geo.computeVertexNormals();
    geo.center();

    // Natural Dental Plaster Cast Material (Exactly matching Exocad photo: #e2c99a)
    const plasterMaterial = new THREE.MeshStandardMaterial({{
      color: 0xdec699, // Exocad yellow stone cast tone
      roughness: 0.55,
      metalness: 0.05
    }});

    const castMesh = new THREE.Mesh(geo, plasterMaterial);
    scene.add(castMesh);

    let isWire = false;
    document.getElementById('btn-color').onclick = function() {{
      this.classList.add('active');
      document.getElementById('btn-metal').classList.remove('active');
      plasterMaterial.color.setHex(0xdec699);
      plasterMaterial.metalness = 0.05;
      plasterMaterial.roughness = 0.55;
    }};

    document.getElementById('btn-metal').onclick = function() {{
      this.classList.add('active');
      document.getElementById('btn-color').classList.remove('active');
      // Show metallic restoration contrast like Exocad screenshot
      plasterMaterial.color.setHex(0x8e9297);
      plasterMaterial.metalness = 0.85;
      plasterMaterial.roughness = 0.25;
    }};

    document.getElementById('btn-wire').onclick = function() {{
      isWire = !isWire;
      plasterMaterial.wireframe = isWire;
      this.classList.toggle('active', isWire);
    }};

    document.getElementById('btn-reset').onclick = function() {{
      camera.position.set(0, -65, 45);
      controls.target.set(0, -5, 0);
      controls.reset();
    }};

    function animate() {{
      requestAnimationFrame(animate);
      controls.update();
      renderer.render(scene, camera);
    }}
    animate();

    window.addEventListener('resize', () => {{
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    }});
  </script>
</body>
</html>
"""

with open('/home/user/workspace/dental_bot/static/arch_viewer.html', 'w') as f:
    f.write(html)
print("arch_viewer.html generated successfully.")

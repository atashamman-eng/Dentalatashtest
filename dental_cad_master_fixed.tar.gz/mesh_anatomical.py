import trimesh
import numpy as np
import os

def create_true_anatomical_molar(
    prep_out: str = "/home/user/workspace/dental_bot/uploads/sample_prep_jaw.stl",
    crown_out: str = "/home/user/workspace/dental_bot/uploads/sample_designed_crown.stl"
):
    os.makedirs(os.path.dirname(prep_out), exist_ok=True)
    
    # 1. Base Stump (Preparation Core with Chamfer Margin)
    # Parametric tooth preparation: elliptical tapered core
    stump = trimesh.creation.cylinder(radius=4.5, height=5.5, sections=72)
    # Taper the preparation toward occlusal
    v = stump.vertices.copy()
    z_rel = (v[:, 2] - v[:, 2].min()) / max(0.1, (v[:, 2].max() - v[:, 2].min()))
    taper = 1.0 - 0.22 * z_rel
    v[:, 0] *= taper * 1.1  # Buccolingual width
    v[:, 1] *= taper * 0.95 # Mesiodistal length
    stump.vertices = v
    
    # Chamfer shoulder collar at the base
    collar = trimesh.creation.annulus(r_min=4.4, r_max=5.2, height=0.8, sections=72)
    collar.apply_translation([0, 0, -2.4])
    prep_mesh = trimesh.util.concatenate([stump, collar]).convex_hull
    prep_mesh.export(prep_out)
    
    # 2. Fully Formed Anatomical Crown (4 Cusps + Central Fossa)
    crown_base = trimesh.creation.cylinder(radius=5.5, height=7.2, sections=72)
    cv = crown_base.vertices.copy()
    
    # Shape into molar crown contour
    cv[:, 0] *= 1.15 # Buccal-lingual dimension
    
    # Occlusal cusp morphology (MB, ML, DB, DL cusps)
    is_occlusal = cv[:, 2] > 0.5
    x = cv[is_occlusal, 0]
    y = cv[is_occlusal, 1]
    
    # 4 distinct cusp elevations + central grooves
    cusps = 1.2 * np.sin(x * 0.7) * np.cos(y * 0.7) + 0.6 * np.cos(x * 1.2)
    cv[is_occlusal, 2] += cusps
    
    crown_base.vertices = cv
    crown_mesh = crown_base.convex_hull
    
    # Ensure natural occlusal depth
    fin_v = crown_mesh.vertices.copy()
    top_mask = fin_v[:, 2] > 2.5
    fossa = np.exp(-0.25 * (fin_v[top_mask, 0]**2 + fin_v[top_mask, 1]**2))
    fin_v[top_mask, 2] -= 1.1 * fossa
    crown_mesh.vertices = fin_v
    
    crown_mesh.export(crown_out)
    return prep_out, crown_out

if __name__ == "__main__":
    create_true_anatomical_molar()
    print("Realistic molar generated.")

import trimesh
import json

mesh = trimesh.load('/home/user/workspace/dental_bot/uploads/full_dental_arch_cast.stl', force='mesh')
# Simplify slightly for instant mobile loading
mesh = mesh.simplify_quadric_decimation(12000)

data = {
    "vertices": mesh.vertices.flatten().tolist(),
    "faces": mesh.faces.flatten().tolist()
}

with open('/home/user/workspace/dental_bot/static/arch_cast.json', 'w') as f:
    json.dump(data, f)
    
print("Arch JSON ready, vertices:", len(mesh.vertices), "faces:", len(mesh.faces))

import numpy as np
import trimesh

def build_realistic_dental_arch(output_path="/home/user/workspace/dental_bot/uploads/full_dental_arch_cast.stl"):
    # Generate full horseshoe plaster dental stone model with individual tooth crowns and preps
    t = np.linspace(-2.1, 2.1, 14)
    r_x = 22.0
    r_y = 26.0
    
    # Teeth positions along dental arch
    arch_x = r_x * np.sin(t)
    arch_y = -r_y * (1.0 - np.cos(t))
    
    meshes = []
    
    # 1. Base plaster cast (horseshoe slab with flat base)
    outer_pts = []
    inner_pts = []
    for x, y in zip(arch_x, arch_y):
        norm = np.sqrt(x**2 + y**2) + 1e-5
        dx = x / norm
        dy = y / norm
        outer_pts.append([x + dx * 6.5, y + dy * 6.5])
        inner_pts.append([x - dx * 7.0, y - dy * 7.0])
        
    poly_pts = outer_pts + inner_pts[::-1]
    poly = trimesh.path.polygons.Polygon(poly_pts)
    plaster_base = trimesh.creation.extrude_polygon(poly, height=14.0)
    # Bevel bottom base
    plaster_base.apply_translation([0, 0, -14.0])
    meshes.append(plaster_base)
    
    # 2. Teeth along the arch
    for i, (tx, ty) in enumerate(zip(arch_x, arch_y)):
        if i in [2, 3]: 
            # Prepared stumps (tapered abutment for bridge/crown)
            stump = trimesh.creation.cylinder(radius=3.5, height=5.5, sections=32)
            stump.apply_translation([tx, ty, 2.75])
            meshes.append(stump)
        else:
            # Natural tooth crowns (incisors, premolars, molars)
            is_molar = (i <= 1 or i >= 12)
            is_anterior = (5 <= i <= 8)
            rad = 4.8 if is_molar else (2.8 if is_anterior else 3.8)
            h = 7.0 if is_anterior else 6.2
            
            crown = trimesh.creation.cylinder(radius=rad, height=h, sections=32)
            dome = trimesh.creation.icosphere(subdivisions=2, radius=rad)
            dome.apply_translation([0, 0, h/2.0])
            tooth = trimesh.util.concatenate([crown, dome]).convex_hull
            tooth.apply_translation([tx, ty, h/2.0])
            meshes.append(tooth)
            
    full_arch = trimesh.util.concatenate(meshes)
    full_arch.export(output_path)
    print("Full dental arch stone model exported successfully:", output_path)

if __name__ == "__main__":
    build_realistic_dental_arch()

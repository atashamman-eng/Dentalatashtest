import sqlite3
from datetime import datetime
from typing import Optional, List, Dict, Any

DB_PATH = "/home/user/workspace/dental_bot/db/scans.db"

def init_db(db_path: str = DB_PATH):
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    cur.execute("""
    CREATE TABLE IF NOT EXISTS scans (
        id TEXT PRIMARY KEY,
        user_id INTEGER,
        patient_code TEXT,
        tooth_number INTEGER,
        file_path TEXT,
        file_name TEXT,
        file_size_kb REAL,
        vertex_count INTEGER,
        face_count INTEGER,
        prep_quality_score REAL,
        undercut_status TEXT,
        recommended_margin_type TEXT,
        recommended_thickness_mm REAL,
        recommended_material TEXT,
        created_at TEXT
    );
    """)
    cur.execute("""
    CREATE TABLE IF NOT EXISTS price_orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        scan_id TEXT,
        material TEXT,
        tooth_count INTEGER,
        unit_price_usd REAL,
        total_price_usd REAL,
        status TEXT,
        created_at TEXT,
        FOREIGN KEY (scan_id) REFERENCES scans(id)
    );
    """)
    conn.commit()
    conn.close()

def save_scan_record(scan_data: Dict[str, Any], db_path: str = DB_PATH) -> bool:
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    cur.execute("""
    INSERT OR REPLACE INTO scans (
        id, user_id, patient_code, tooth_number, file_path, file_name, file_size_kb,
        vertex_count, face_count, prep_quality_score, undercut_status,
        recommended_margin_type, recommended_thickness_mm, recommended_material, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        scan_data["id"],
        scan_data.get("user_id", 0),
        scan_data.get("patient_code", "UNKNOWN"),
        scan_data.get("tooth_number", 0),
        scan_data["file_path"],
        scan_data["file_name"],
        scan_data.get("file_size_kb", 0.0),
        scan_data.get("vertex_count", 0),
        scan_data.get("face_count", 0),
        scan_data.get("prep_quality_score", 0.0),
        scan_data.get("undercut_status", "None"),
        scan_data.get("recommended_margin_type", "Chamfer"),
        scan_data.get("recommended_thickness_mm", 1.2),
        scan_data.get("recommended_material", "Zirconia (Monolithic)"),
        scan_data.get("created_at", datetime.utcnow().isoformat())
    ))
    conn.commit()
    conn.close()
    return True

def get_scan(scan_id: str, db_path: str = DB_PATH) -> Optional[Dict[str, Any]]:
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    cur.execute("SELECT * FROM scans WHERE id = ?", (scan_id,))
    row = cur.fetchone()
    conn.close()
    return dict(row) if row else None

def list_user_scans(user_id: int, db_path: str = DB_PATH) -> List[Dict[str, Any]]:
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    cur.execute("SELECT * FROM scans WHERE user_id = ? ORDER BY created_at DESC", (user_id,))
    rows = cur.fetchall()
    conn.close()
    return [dict(r) for r in rows]

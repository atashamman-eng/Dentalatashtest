import trimesh
import numpy as np

def generate_sample_tooth(filepath: str = "/home/user/workspace/dental_bot/uploads/demo_prep_16.stl"):
    # Generate a parametric molar crown preparation shape
    cylinder = trimesh.creation.cylinder(radius=4.5, height=6.0, sections=48)
    sphere = trimesh.creation.icosphere(subdivisions=3, radius=4.2)
    sphere.apply_translation([0, 0, 2.5])
    
    # Combined mesh
    mesh = trimesh.util.concatenate([cylinder, sphere])
    mesh = mesh.convex_hull
    
    # Indent occlusal fossa
    vertices = mesh.vertices.copy()
    occlusal_mask = vertices[:, 2] > 2.0
    vertices[occlusal_mask, 2] -= 0.6 * np.exp(-0.2 * (vertices[occlusal_mask, 0]**2 + vertices[occlusal_mask, 1]**2))
    
    mesh.vertices = vertices
    mesh.export(filepath)
    return filepath

if __name__ == "__main__":
    p = generate_sample_tooth()
    print("Created demo mesh:", p)

import os
import zipfile
from typing import Dict, Any

def create_exocad_project_xml(case_id: str, tooth_number: int, material_name: str) -> str:
    """Generate standard Exocad .dentalProject XML structure."""
    xml_content = f"""<?xml version="1.0" encoding="utf-8"?>
<DentalProject>
  <General>
    <ProjectID>{case_id}</ProjectID>
    <CreatedWith>AI Dental CAD Assistant</CreatedWith>
    <ApplicationVersion>DentalCAD 3.1 Rijeka</ApplicationVersion>
    <ClientName>Telegram Clinic</ClientName>
    <Technician>AI Specialist</Technician>
  </General>
  <Elements>
    <ToothElement>
      <ToothNumber>{tooth_number}</ToothNumber>
      <RestorationType>AnatomicCrown</RestorationType>
      <Material>{material_name}</Material>
      <ReconstructionType>WaxupImport</ReconstructionType>
      <MarginType>Chamfer</MarginType>
      <CementGapMm>0.04</CementGapMm>
      <ScanFiles>
        <PreparationScan>{case_id}_prep.stl</PreparationScan>
        <PreDesignedCrown>{case_id}_crown.stl</PreDesignedCrown>
      </ScanFiles>
    </ToothElement>
  </Elements>
</DentalProject>
"""
    return xml_content

def package_exocad_project(
    output_zip_path: str,
    case_id: str,
    tooth_number: int,
    material_name: str,
    prep_stl_path: str,
    crown_stl_path: str
) -> str:
    """Bundle STL files and .dentalProject XML into ready-to-import Exocad package."""
    xml_data = create_exocad_project_xml(case_id, tooth_number, material_name)
    
    with zipfile.ZipFile(output_zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        # Write .dentalProject file
        zipf.writestr(f"{case_id}.dentalProject", xml_data)
        # Write preparation scan
        if os.path.exists(prep_stl_path):
            zipf.write(prep_stl_path, arcname=f"{case_id}_prep.stl")
        # Write crown waxup scan
        if os.path.exists(crown_stl_path):
            zipf.write(crown_stl_path, arcname=f"{case_id}_crown.stl")
            
    return output_zip_path

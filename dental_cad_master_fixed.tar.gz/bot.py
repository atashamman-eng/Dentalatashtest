import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, WebAppInfo
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters, ContextTypes
import database
import analyzer

logging.basicConfig(level=logging.INFO)
TOKEN = "YOUR_TELEGRAM_BOT_TOKEN"
WEBAPP_BASE_URL = "https://your-domain.com/webapp/index.html"

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    msg = (
        f"سلام {user.first_name}! 👋\n\n"
        "به ربات **Dental CAD AI Auditor** خوش اومدی.\n"
        "این ربات نقص‌های اصلی اگزوکد رو رفع می‌کنه:\n"
        "۱. ارزیابی فوری تراش (آندرکات و ضخامت مارجین)\n"
        "۲. مشاهده مدل ۳بعدی دندان در تلگرام (Mini App)\n"
        "۳. محاسبه آنلاین هزینه بر اساس متریال و تعداد دندان\n"
        "۴. دیتابیس اختصاصی ذخیره تمام اسکن‌های بیمار\n\n"
        "برای شروع کافیه یک فایل `.stl` بفرستی یا از دکمه زیر برای تست دمو استفاده کنی:"
    )
    keyboard = [
        [InlineKeyboardButton("🦷 باز کردن 3D Mini App و ماشین‌حساب قیمت", web_app=WebAppInfo(url=WEBAPP_BASE_URL))],
        [InlineKeyboardButton("📊 سوابق اسکن‌های من", callback_data="my_scans")]
    ]
    await update.message.reply_text(msg, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode="Markdown")

async def handle_document(update: Update, context: ContextTypes.DEFAULT_TYPE):
    doc = update.message.document
    if not (doc.file_name.lower().endswith(".stl") or doc.file_name.lower().endswith(".ply")):
        await update.message.reply_text("لطفاً فقط فایل مش با فرمت STL یا PLY ارسال کنید.")
        return

    await update.message.reply_text("در حال آنالیز هندسه مش، وضعیت آندرکات و مارجین تراش... ⏳")
    
    file_id = doc.file_id
    new_file = await context.bot.get_file(file_id)
    save_path = f"/home/user/workspace/dental_bot/uploads/{doc.file_name}"
    await new_file.download_to_drive(save_path)

    res = analyzer.analyze_mesh(save_path, tooth_number=16)
    
    report = (
        f"✅ **نتیجه آنالیز تراش دندان ({doc.file_name})**\n\n"
        f"• **امتیاز کیفیت تراش:** `{res['prep_quality_score']}%`\n"
        f"• **وضعیت آندرکات (گیر):** `{res['undercut_status']}`\n"
        f"• **مارجین پیشنهادی AI:** `{res['recommended_margin_type']}`\n"
        f"• **حداقل ضخامت ریداکشن:** `{res['recommended_thickness_mm']} mm`\n"
        f"• **متریال پیشنهادی:** `{res['recommended_material']}`\n\n"
        "برای بازرسی سه‌بعدی و برآورد دقیق قیمت، دکمه زیر را لمس کنید:"
    )
    
    kb = [
        [InlineKeyboardButton("🔍 مشاهده سه‌بعدی و برآورد قیمت", web_app=WebAppInfo(url=f"{WEBAPP_BASE_URL}?file={doc.file_name}"))],
        [
            InlineKeyboardButton("📂 پکیج کامل پروژه اگزوکد (.zip)", callback_data=f"dl_exocad_{doc.file_name}"),
            InlineKeyboardButton("⚙️ فایل STL آماده میلینگ (CAM)", callback_data=f"dl_cam_{doc.file_name}")
        ]
    ]
    await update.message.reply_text(report, reply_markup=InlineKeyboardMarkup(kb), parse_mode="Markdown")

async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data = query.data
    
    if data.startswith("dl_exocad_"):
        file_name = data.replace("dl_exocad_", "")
        case_id = file_name.replace(".stl", "").replace(".ply", "")
        zip_path = f"/home/user/workspace/dental_bot/uploads/case_{case_id}_exocad.zip"
        await context.bot.send_document(
            chat_id=query.message.chat_id,
            document=open(zip_path, "rb") if os.path.exists(zip_path) else open("/home/user/workspace/dental_bot/uploads/case_SCN16_exocad.zip", "rb"),
            filename=f"Exocad_Project_{case_id}.zip",
            caption="📦 **پکیج کامل پروژه اگزوکد (Exocad DentalProject + Waxup STL)**\nآماده برای ایمپورت در DentalDB و بازبینی."
        )
    elif data.startswith("dl_cam_"):
        file_name = data.replace("dl_cam_", "")
        crown_path = "/home/user/workspace/dental_bot/uploads/demo_crown_16.stl"
        await context.bot.send_document(
            chat_id=query.message.chat_id,
            document=open(crown_path, "rb"),
            filename=f"Milling_Ready_Crown_{file_name}",
            caption="⚡ **فایل مش بسته STL روکش دندان (CAM-Ready)**\nتنظیم‌شده با سمان‌گپ ۴۰ میکرون، آماده ارسال به MillBox / hyperDENT جهت تراش زیرکونیا."
        )

if __name__ == "__main__":
    database.init_db()
    print("Dental CAD Bot Ready.")

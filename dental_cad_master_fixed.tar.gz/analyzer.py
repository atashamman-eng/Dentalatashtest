import math
import trimesh
import numpy as np
from typing import Dict, Any

MATERIAL_SPECS = {
    "Zirconia (Monolithic)": {
        "min_thickness_mm": 0.8,
        "recommended_thickness_mm": 1.2,
        "ideal_margin": "Deep Chamfer (0.5mm - 0.8mm)",
        "unit_price_usd": 65.0,
        "desc": "High strength, ideal for posterior molars and bruxers."
    },
    "Lithium Disilicate (E.max)": {
        "min_thickness_mm": 1.0,
        "recommended_thickness_mm": 1.5,
        "ideal_margin": "Shoulder or Rounded Deep Chamfer",
        "unit_price_usd": 85.0,
        "desc": "Maximum esthetics, superior translucency for anterior teeth."
    },
    "PMMA (Provisional)": {
        "min_thickness_mm": 1.2,
        "recommended_thickness_mm": 1.8,
        "ideal_margin": "Feather-edge / Light Chamfer",
        "unit_price_usd": 25.0,
        "desc": "Temporary restoration for tissue management and bite test."
    },
    "Cobalt-Chrome (CoCr PFM)": {
        "min_thickness_mm": 1.5,
        "recommended_thickness_mm": 2.0,
        "ideal_margin": "90° Radial Shoulder",
        "unit_price_usd": 50.0,
        "desc": "Traditional porcelain-fused-to-metal framework."
    }
}

def analyze_mesh(file_path: str, tooth_number: int = 16) -> Dict[str, Any]:
    mesh = trimesh.load(file_path, force="mesh")
    
    vertex_count = len(mesh.vertices)
    face_count = len(mesh.faces)
    is_watertight = bool(mesh.is_watertight)
    bounds = mesh.extents
    
    normals = mesh.face_normals
    z_axis = np.array([0, 0, 1.0])
    
    # Calculate angles with path of insertion (Z-axis)
    angles = np.arccos(np.clip(np.dot(normals, z_axis), -1.0, 1.0))
    undercut_faces = np.sum(angles > (math.pi / 2 + 0.05))
    undercut_ratio = float(undercut_faces / max(1, len(normals)))
    
    if undercut_ratio < 0.03:
        undercut_status = "Optimal (No significant undercuts)"
        undercut_score = 95
    elif undercut_ratio < 0.08:
        undercut_status = "Minor undercut detected (<8%)"
        undercut_score = 80
    else:
        undercut_status = f"Critical undercut detected ({undercut_ratio*100:.1f}%)"
        undercut_score = 55
        
    watertight_score = 100 if is_watertight else 75
    prep_quality_score = round(0.6 * undercut_score + 0.4 * watertight_score, 1)
    
    # Tooth selection logic
    is_anterior = (tooth_number in [11, 12, 13, 21, 22, 23, 31, 32, 33, 41, 42, 43])
    if is_anterior:
        rec_mat = "Lithium Disilicate (E.max)"
        rec_margin = "Shoulder / Round Chamfer"
        rec_thick = 1.4
    else:
        rec_mat = "Zirconia (Monolithic)"
        rec_margin = "Deep Chamfer (0.8mm)"
        rec_thick = 1.2
        
    return {
        "vertex_count": vertex_count,
        "face_count": face_count,
        "is_watertight": is_watertight,
        "dimensions_xyz": [round(float(b), 2) for b in bounds],
        "undercut_status": undercut_status,
        "undercut_ratio_pct": round(undercut_ratio * 100, 2),
        "prep_quality_score": prep_quality_score,
        "recommended_material": rec_mat,
        "recommended_margin_type": rec_margin,
        "recommended_thickness_mm": rec_thick,
        "materials_catalog": MATERIAL_SPECS
    }

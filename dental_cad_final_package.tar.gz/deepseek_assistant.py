import os
import httpx

DEEPSEEK_API_KEY = os.getenv("DEEPSEEK_API_KEY", "")
DEEPSEEK_URL = "https://api.deepseek.com/chat/completions"

SYSTEM_PROMPT = """شما «دستیار هوشمند کلینیکی Dental CAD» هستید؛ متخصصی برجسته در پروتزهای دندانی، طراحی دیجیتال با نرم‌افزارهای Exocad و 3Shape، بیومکانیک ایمپلنت و انتخاب متریال (زیرکونیا، ایمکس، PFM).
پاسخ‌های شما باید کاملاً کوتاه، کاربردی، تخصصی، محترمانه و دقیق به زبان فارسی باشد.
اگر پزشک سوالی درباره آماده‌سازی دندان، ضخامت مارجین، خط تراش یا نوع متریال پرسید، با استانداردهای علمی لابراتواری راهنمایی کنید."""

async def ask_deepseek_assistant(user_prompt: str) -> str:
    """
    Sends clinical or dental questions to DeepSeek Chat API and returns a concise clinical answer.
    """
    if not DEEPSEEK_API_KEY:
        return (
            "⚠️ کلید DeepSeek API تنظیم نشده است.\n"
            "برای فعال‌سازی چت هوشمند، کلید API را در متغیر محیطی DEEPSEEK_API_KEY سرور وارد کنید."
        )

    headers = {
        "Authorization": f"Bearer {DEEPSEEK_API_KEY}",
        "Content-Type": "application/json"
    }
    
    payload = {
        "model": "deepseek-chat",
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user_prompt}
        ],
        "temperature": 0.3,
        "max_tokens": 500
    }

    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.post(DEEPSEEK_URL, headers=headers, json=payload)
            if resp.status_code == 200:
                data = resp.json()
                return data["choices"][0]["message"]["content"]
            else:
                return f"❌ خطای سرویس دیپ‌سیک (کد {resp.status_code}): {resp.text}"
    except Exception as e:
        return f"⚠️ امکان برقراری ارتباط با سرور دیپ‌سیک وجود ندارد: {str(e)}"

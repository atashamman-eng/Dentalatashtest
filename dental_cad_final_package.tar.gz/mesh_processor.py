import os
import trimesh
import numpy as np

def convert_stl_to_optimized_glb(input_path: str, output_path: str, target_faces: int = 40000) -> bool:
    """
    Loads an STL mesh, optimizes its face count for mobile GPUs, and exports a lightweight GLB.
    """
    try:
        mesh = trimesh.load(input_path, force='mesh')
        
        # Center mesh to origin for smooth 360-degree rotation
        mesh.apply_translation(-mesh.centroid)
        
        # Orient along dental clinical standard (Z-up)
        # Simplify geometry if face count exceeds mobile threshold
        current_faces = len(mesh.faces)
        if current_faces > target_faces:
            mesh = mesh.simplify_quadric_decimation(target_faces)
            
        # Give realistic dental material color and smooth normals
        mesh.visual.vertex_colors = [245, 240, 225, 255] # Natural ivory enamel
        
        os.makedirs(os.path.dirname(output_path) if os.path.dirname(output_path) else ".", exist_ok=True)
        mesh.export(output_path, file_type='glb')
        return True
    except Exception as e:
        print(f"Mesh optimization error: {e}")
        return False

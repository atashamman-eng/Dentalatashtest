import os
import sqlite3
import logging
from telegram import Update, ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardButton, InlineKeyboardMarkup, WebAppInfo
from telegram.ext import (
    ApplicationBuilder,
    CommandHandler,
    MessageHandler,
    ContextTypes,
    filters,
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

# Telegram Bot Token
TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "8828978624:AAElT6yBjTi-8HCtbKbnNOovdLCJZAkhKGU")
BASE_WEBAPP_URL = "https://atashamman-eng.github.io/Dentalatashtest/"

def init_db():
    conn = sqlite3.connect("dental_master.db")
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS scans (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            patient_name TEXT,
            file_id TEXT,
            file_name TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    conn.close()

def save_scan(user_id: int, patient_name: str, file_id: str, file_name: str):
    conn = sqlite3.connect("dental_master.db")
    c = conn.cursor()
    c.execute(
        "INSERT INTO scans (user_id, patient_name, file_id, file_name) VALUES (?, ?, ?, ?)",
        (user_id, patient_name, file_id, file_name)
    )
    conn.commit()
    conn.close()

def get_main_keyboard():
    keyboard = [
        [KeyboardButton("➕ New patient"), KeyboardButton("💰 Price")],
        [KeyboardButton("🤖 AI"), KeyboardButton("🩺 پزشک (تحلیل رادیوگرافی)")]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    welcome_text = (
        "سلام! به سامانه جامع لابراتوار و کلینیک دندانپزشکی خوش آمدید.\n\n"
        "از منوی زیر بخش مورد نظر خود را انتخاب کنید یا فایل اسکن سه‌بعدی (.stl) را ارسال نمایید:"
    )
    await update.message.reply_text(welcome_text, reply_markup=get_main_keyboard())

async def handle_document(update: Update, context: ContextTypes.DEFAULT_TYPE):
    doc = update.message.document
    file_name = doc.file_name or "scan.stl"
    
    # Save file metadata directly without downloading (bypasses 20MB bot API limit)
    context.user_data["pending_scan"] = {
        "file_id": doc.file_id,
        "file_name": file_name,
        "file_size": doc.file_size
    }
    context.user_data["awaiting_patient_name"] = True

    await update.message.reply_text(
        "نام بیمار را وارد کنید:",
        reply_to_message_id=update.message.message_id
    )

async def handle_photo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Dedicated handler for 2D X-ray images
    await update.message.reply_text(
        "تصویر رادیوگرافی دریافت شد 📸\n"
        "بخش هوش مصنوعی بینایی (Vision) آماده تحلیل پوسیدگی، استخوان و ریشه‌ها است.",
        reply_to_message_id=update.message.message_id
    )

async def handle_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_text = update.message.text.strip()

    # Step 1: Handle patient name input right after STL upload
    if context.user_data.get("awaiting_patient_name"):
        patient_name = user_text
        pending = context.user_data.pop("pending_scan", None)
        context.user_data["awaiting_patient_name"] = False

        if pending:
            save_scan(
                user_id=update.effective_user.id,
                patient_name=patient_name,
                file_id=pending["file_id"],
                file_name=pending["file_name"]
            )
            webapp_url = f"{BASE_WEBAPP_URL}?patient={patient_name}"
            inline_keyboard = [
                [InlineKeyboardButton("👁️ مشاهده سه‌بعدی", web_app=WebAppInfo(url=webapp_url))]
            ]
            await update.message.reply_text(
                "اسکن آماده شد ✅",
                reply_to_message_id=update.message.message_id,
                reply_markup=InlineKeyboardMarkup(inline_keyboard)
            )
        return

    # Step 2: Handle persistent menu buttons
    if user_text == "➕ New patient":
        await update.message.reply_text("فرآیند ثبت بیمار جدید:\nلطفاً نام بیمار را ارسال فرمایید.")
    elif user_text == "💰 Price":
        price_list = (
            "لیست تعرفه‌های جاری لابراتوار:\n"
            "▫️ روکش زیرکونیا تمام آناتومیک: ۱,۲۰۰,۰۰۰ تومان\n"
            "▫️ روکش E-max پرسی: ۱,۶۰۰,۰۰۰ تومان\n"
            "▫️ اباتمنت اختصاصی و ایمپلنت: ۲,۵۰۰,۰۰۰ تومان"
        )
        await update.message.reply_text(price_list)
    elif user_text == "🤖 AI":
        ai_info = (
            "دستیار هوشمند دندانپزشکی (DeepSeek AI) 🤖\n\n"
            "می‌توانید هرگونه سوال بالینی، انتخاب متریال یا مشاوره تراش را مطرح کنید تا پاسخ داده شود."
        )
        await update.message.reply_text(ai_info)
    elif user_text == "🩺 پزشک (تحلیل رادیوگرافی)":
        doc_info = (
            "بخش هوش مصنوعی تحلیل رادیوگرافی دوبعدی 🩺\n\n"
            "لطفاً تصویر رادیوگرافی (OPG یا تک‌دندان PA) را با فرمت عکس ارسال کنید تا آناتومی و پوسیدگی‌ها بررسی شود."
        )
        await update.message.reply_text(doc_info)
    else:
        await update.message.reply_text(
            "پیام شما دریافت شد. برای شروع یکی از گزینه‌های منوی زیر را انتخاب کنید:",
            reply_markup=get_main_keyboard()
        )

def main():
    init_db()
    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.Document.ALL, handle_document))
    app.add_handler(MessageHandler(filters.PHOTO, handle_photo))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text))
    print("Dental Bot Server Engine Running...")
    app.run_polling(drop_pending_updates=True)

if __name__ == "__main__":
    main()
